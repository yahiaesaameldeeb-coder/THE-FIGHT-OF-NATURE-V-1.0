@echo off
setlocal
set "ROOT_DIR=%~dp0"
set "GRADLE_VERSION=8.9"
set "CACHE_DIR=%USERPROFILE%\.gradle\wrapper\dists\gradle-bootstrap\%GRADLE_VERSION%"
set "DIST_DIR=%CACHE_DIR%\gradle-%GRADLE_VERSION%"
set "ZIP=%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
if exist "%DIST_DIR%\bin\gradle.bat" goto run
if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
if not exist "%ZIP%" powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
if exist "%DIST_DIR%" rmdir /s /q "%DIST_DIR%"
powershell -NoProfile -Command "Expand-Archive -Force '%ZIP%' '%CACHE_DIR%'"
:run
call "%DIST_DIR%\bin\gradle.bat" -p "%ROOT_DIR%" %*
endlocal
