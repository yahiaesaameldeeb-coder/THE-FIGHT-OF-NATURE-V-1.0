The Fight Of Nature - Android Build Ready

This project is configured for Android Gradle Plugin 8.7.3 and Gradle 8.9.

Build debug APK:
  ./gradlew assembleDebug

Build release APK:
  ./gradlew assembleRelease

Build Google Play AAB:
  ./gradlew bundleRelease

The included gradlew bootstrap downloads Gradle 8.9 automatically if it is not already installed.
Android SDK with API 35 and a compatible JDK (17 recommended) are required.
